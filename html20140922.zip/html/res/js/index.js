$(function(){
	slideImg();
	hotspotPage();
	imgHoverAmp();
});

/**
 * 图片幻灯片展示
 */
function slideImg(){
	var div = $('#SlideDiv'), list = div.children('ul.list'), tab = div.children('ul.tab');
	var fli = list.children(':first'), fw = fli.outerWidth(), tabA = tab.find('li>a');
	var next = 1, l = tabA.length;
	list.append(fli.clone()).width((l + 1) * fw);
	
	var am = function(){
		tabA.removeClass('over');
		var i = next;
		if(next >= l){
			next = l;
			i = 0;
		}
		tabA.filter(':eq(' + i +')').addClass('over');
		list.animate({
			marginLeft: -fw * next
		}, function(){
			if(next == l)
				list.css('margin-left', 0);
			next++;
			if(next > l)
				next = 1;
			toint = setTimeout(am, 5000);
		});
	};
	var toint = setTimeout(am, 5000);
	
	tabA.mouseenter(function(){
		list.stop(true, true);
		clearTimeout(toint);
		next = $(this).parent().index();
		am();
	});
}

/**
 * 热门景点翻页
 */
function hotspotPage(){
	var div = $('#HotspotPage'), prev = div.children('.page:first'), next = div.children('.page:last');
	var ul = div.find('.con>ul'), li = ul.children('li'), liw = li.outerWidth(), ulw = liw * li.length;
	ul.width(ulw);
	ulw = -ulw + liw;
	
	var checkOver = function(){
		prev.addClass('over');
		next.addClass('over');
		var curm = parseInt(ul.css('margin-left'));
		if(curm >= 0){
			prev.removeClass('over');
			ul.css('margin-left', 0);
		}else if(curm <= ulw){
			next.removeClass('over');
			ul.css('margin-left', ulw);
		}
	};
	checkOver();
	
	var am = function(b){
		if(!$(this).hasClass('over'))
			return;
		ul.animate({
			marginLeft: (b ? '+=' : '-=') + liw
		}, function(){
			checkOver();
		});
	};
	prev.click(function(){
		am.call(this, true);
	});
	next.click(function(){
		am.call(this, false);
	});
}

/**
 * 鼠标移到图片上时的放大效果
 */
function imgHoverAmp(){
	var amp = 10, m = amp / 2;
	$('img[hoverAmp]').hover(function(){
		$(this).animate({
			width: '+=' + amp,
			height: '+=' + amp,
			marginLeft: '-=' + m,
			marginTop: '-=' + m
		}, 'fast');
	}, function(){
		$(this).animate({
			width: '-=' + amp,
			height: '-=' + amp,
			marginLeft:'+=' + m,
			marginTop: '+=' + m
		});
	}, 'fast');
}