package org.springside.modules.metrics.exporter;

/**
 * Export as Restful Service in json format.
 */
public class RestExporter {

}
