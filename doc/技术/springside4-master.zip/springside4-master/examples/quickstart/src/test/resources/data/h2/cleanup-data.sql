delete from ss_task;
delete from ss_user;