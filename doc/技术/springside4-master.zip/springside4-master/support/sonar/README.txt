Exported Sonar Code Quality Platform profile.

springside-*.xml is a springside version base on sonar default profle.


See the wiki for details:

https://github.com/springside/springside4/wiki/Sonar