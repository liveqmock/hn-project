Eclipse Preference file, include Code Format, Cleanup, Warning and other settings. 

See the wiki for details:

https://github.com/springside/springside4/wiki/Eclipse