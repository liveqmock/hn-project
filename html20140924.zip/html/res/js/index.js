$(function(){
	slideBarEffect();
	hotlineSale();
	hotspotPage();
	hotspotSale();
	polymerEffect();
	imgHoverAmp();
	imgHoverOpacity();
	headShow();
	windowScroll();
});

/**
 * 幻灯片栏效果（菜单、焦点图）
 */
function slideBarEffect(){
	var div = $('#SlideDiv');
	//左侧菜单
	var menuBox = div.find('.mainbox>.sl');
	menuBox.find('ul>li').hover(function(){
		$(this).addClass('over');
		$(this).children('.mc').show('fast');
	}, function(){
		$(this).removeClass('over');
		$(this).children('.mc').hide();
	});
	//中间焦点图
	var focusImg = div.find('.mainbox>.sc'), list = focusImg.children('ul.list'), tab = focusImg.children('ul.tab');
	var fli = list.children(':first'), fw = fli.outerWidth(), tabA = tab.find('li>a');
	var next = 1, l = tabA.length;
	list.append(fli.clone()).width((l + 1) * fw);
	
	var am = function(){
		tabA.removeClass('over');
		var i = next;
		if(next >= l){
			next = l;
			i = 0;
		}
		tabA.filter(':eq(' + i +')').addClass('over');
		list.animate({
			marginLeft: -fw * next
		}, function(){
			if(next == l)
				list.css('margin-left', 0);
			next++;
			if(next > l)
				next = 1;
			toint = setTimeout(am, 5000);
		});
	};
	var toint = setTimeout(am, 5000);
	
	tabA.mouseenter(function(){
		list.stop(true, true);
		clearTimeout(toint);
		next = $(this).parent().index();
		am();
	});
}

/**
 * 热门线路热销Tab切换
 */
function hotlineSale(){
	var div = $('#HotlineSale'), dda = div.find('dl>dd>a');
	var uls = div.find('.rb>ul');
	dda.mouseenter(function(){
		dda.removeClass('over');
		$(this).addClass('over');
		uls.hide();
		$(uls[dda.index(this)]).show();
	});
}

/**
 * 热门景点翻页
 */
function hotspotPage(){
	var div = $('#HotspotPage'), prev = div.children('.page:first'), next = div.children('.page:last');
	var ul = div.find('.con>ul'), li = ul.children('li'), liw = li.outerWidth(), ulw = liw * li.length;
	ul.width(ulw);
	ulw = -ulw + liw;
	
	var checkOver = function(){
		prev.addClass('over');
		next.addClass('over');
		var curm = parseInt(ul.css('margin-left'));
		if(curm >= 0){
			prev.removeClass('over');
			ul.css('margin-left', 0);
		}else if(curm <= ulw){
			next.removeClass('over');
			ul.css('margin-left', ulw);
		}
	};
	checkOver();
	
	var am = function(b){
		if(!$(this).hasClass('over'))
			return;
		ul.animate({
			marginLeft: (b ? '+=' : '-=') + liw
		}, function(){
			checkOver();
		});
	};
	prev.click(function(){
		am.call(this, true);
	});
	next.click(function(){
		am.call(this, false);
	});
}

/**
 * 热门景点促销效果
 */
function hotspotSale(){
	$('#HotspotSale>li').hover(function(){
		$(this).animate({
			paddingLeft: 0,
			paddingRight: 0
		});
	}, function(){
		$(this).animate({
			paddingLeft: 5,
			paddingRight: 5
		});
	});
}

/**
 * 聚合图片效果
 */
function polymerEffect(){
	var lis = $('#PolymerBar li:not(.nom)'), mks = lis.find('.mk'), mts = lis.find('.mt');
	lis.hover(function(){
		mts.hide();
		mks.css('opacity', 0);
		var t = $(this), mk = t.find('.mk'), mt = t.find('.mt');
		mk.animate({
			opacity: 0.6
		}, function(){
			mt.show();
		});
	}, function(){
		var t = $(this);
		t.find('.mt').hide();
		t.find('.mk').css('opacity', 0);
	}).find('.mk').css('opacity', 0).show();
}

/**
 * 鼠标移到图片上时的放大效果
 */
function imgHoverAmp(){
	var amp = 10, m = amp / 2;
	$('img[hoverAmp]').hover(function(){
		$(this).animate({
			width: '+=' + amp,
			height: '+=' + amp,
			marginLeft: '-=' + m,
			marginTop: '-=' + m
		}, 'fast');
	}, function(){
		$(this).animate({
			width: '-=' + amp,
			height: '-=' + amp,
			marginLeft: '+=' + m,
			marginTop: '+=' + m
		}, 'fast');
	});
}

/**
 * 鼠标移到图片上时的透明度变化
 */
function imgHoverOpacity(){
	$('img[hoverOpacity]').hover(function(){
		$(this).animate({
			opacity: ($(this).attr('hoverOpacity') == 1 ? 0.6 : 1)
		}, 'slow');
	}, function(){
		$(this).animate({
			opacity: ($(this).attr('hoverOpacity') == 1 ? 1 : 0.6)
		});
	}).css('opacity', 0.6).filter('[hoverOpacity="1"]').css('opacity', 1);
}

/**
 * 头部一些下拉显示效果
 */
function headShow(){
	var login = $('#HeadTop>.con>.login'), l_name = login.children('.name'), l_ul = login.children('ul');
	login.hover(function(){
		l_name.addClass('over');
		l_ul.slideDown('fast');
	}, function(){
		l_name.removeClass('over');
		l_ul.slideUp('fast');
	});
	var search = $('#HeadTop>.con>.search'), s_si = search.children('.si'), s_ss = search.children('.ss');
	search.hover(function(){
		s_si.addClass('over');
		s_ss.animate({height: 'show'}, 'fast');
	}, function(){
		s_si.removeClass('over');
		s_ss.hide();
	});
	var ssl = s_ss.children('.ssl'), ssl_ul = ssl.children('ul');
	ssl.hover(function(){
		ssl_ul.slideDown('fast');
	}, function(){
		ssl_ul.slideUp('fast');
	});
	var ssl_li = ssl_ul.find('li'), ssl_ts = ssl.find('.sslt>span');
	ssl_li.click(function(){
		ssl_ts.text($(this).text());
		ssl_li.show();
		$(this).hide();
	});
}

/**
 * 窗口滚动时的一些效果（小导航栏、背景、回到顶部）
 */
function windowScroll(){
	var body = $('body'), tip = $('#FootTip'), ht = $('#HeadTop');
	var logo = ht.find('.logo'), menu = ht.find('.menu'), search = ht.find('.search');
	var mainTop = 392, logoTop = 94, menuTop = 207, searchTop = 298;
	
	//初始化时背景定住
	body.css('background-attachment', 'fixed');
	
	//头部logo,menu,search显示隐藏
	var headFn = function(b, obj){
		if(b)
			obj.show('fast');
		else
			obj.hide('fast');
	};
	//背景跟随滚动、定住
	var bodyBgFn = function(b){
		body.css({
			'background-attachment': b ? 'scroll' : 'fixed',
			'background-position': b ? 'center 428px' : 'center 0'
		});
	};
	//回到顶部显示、隐藏
	var tipFn = function(b){
		tip.animate({
			bottom: b ? 60 : 0,
			opacity: b ? 'show' : 'hide'
		});
	};
	
	var cbFn = function(fn, b1, b2, obj){
		if((b1 && b2) || (!b1 && !b2))
			fn(!b1, obj);
	};
	$(window).scroll(function(){
		var top = $(this).scrollTop();
		cbFn(bodyBgFn, top < mainTop, 'fixed' != body.css('background-attachment'));
		cbFn(tipFn, top < mainTop, tip.is(':visible'));
		cbFn(headFn, top < logoTop, logo.is(':visible'), logo);
		cbFn(headFn, top < menuTop, menu.is(':visible'), menu);
		cbFn(headFn, top < searchTop, search.is(':visible'), search);
	});
	
	tip.children('.gotop').click(function(){
		$(window).scrollTop(0);
	});
}