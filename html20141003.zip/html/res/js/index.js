$(function(){
	slideBarEffect();
	hotlineSale();
	hotspotPage();
	hotspotSale();
	polymerEffect();
	imgHoverAmp();
	imgHoverOpacity();
	headShow();
	windowScroll();
});

/**
 * 幻灯片栏效果（菜单、焦点图）
 */
function slideBarEffect(){
	var div = $('#SlideDiv');
	//左侧菜单
	var menuBox = div.find('.mainbox>.sl');
	menuBox.find('ul>li').hover(function(){
		$(this).addClass('over');
		$(this).children('.mc').show('fast');
	}, function(){
		$(this).removeClass('over');
		$(this).children('.mc').hide();
	});
	//中间焦点图
	var focusImg = div.find('.mainbox>.sc'), list = focusImg.children('ul.list'), tab = focusImg.children('ul.tab');
	var fli = list.children(':first'), fw = fli.outerWidth(), tabA = tab.find('li>a');
	var next = 1, l = tabA.length;
	list.append(fli.clone()).width((l + 1) * fw);
	
	var am = function(){
		tabA.removeClass('over');
		var i = next;
		if(next >= l){
			next = l;
			i = 0;
		}
		tabA.filter(':eq(' + i +')').addClass('over');
		list.animate({
			marginLeft: -fw * next
		}, function(){
			if(next == l)
				list.css('margin-left', 0);
			next++;
			if(next > l)
				next = 1;
			toint = setTimeout(am, 5000);
		});
	};
	var toint = setTimeout(am, 5000);
	
	tabA.mouseenter(function(){
		list.stop(true, true);
		clearTimeout(toint);
		next = $(this).parent().index();
		am();
	});
}

/**
 * 热门线路热销Tab切换
 */
function hotlineSale(){
	var div = $('#HotlineSale'), dda = div.find('dl>dd>a');
	var uls = div.find('.rb>ul');
	dda.mouseenter(function(){
		dda.removeClass('over');
		$(this).addClass('over');
		uls.hide();
		$(uls[dda.index(this)]).show();
	});
}

/**
 * 热门景点翻页
 */
function hotspotPage(){
	var div = $('#HotspotPage'), prev = div.children('.page:first'), next = div.children('.page:last');
	var ul = div.find('.con>ul'), li = ul.children('li'), liw = li.outerWidth(), ulw = liw * li.length;
	ul.width(ulw);
	ulw = -ulw + liw;
	
	var checkOver = function(){
		prev.addClass('over');
		next.addClass('over');
		var curm = parseInt(ul.css('margin-left'));
		if(curm >= 0){
			prev.removeClass('over');
			ul.css('margin-left', 0);
		}else if(curm <= ulw){
			next.removeClass('over');
			ul.css('margin-left', ulw);
		}
	};
	checkOver();
	
	var am = function(b){
		if(!$(this).hasClass('over'))
			return;
		ul.animate({
			marginLeft: (b ? '+=' : '-=') + liw
		}, function(){
			checkOver();
		});
	};
	prev.click(function(){
		am.call(this, true);
	});
	next.click(function(){
		am.call(this, false);
	});
}

/**
 * 热门景点促销效果
 */
function hotspotSale(){
	$('#HotspotSale>li').hover(function(){
		$(this).animate({
			paddingLeft: 0,
			paddingRight: 0
		}, 'fast');
	}, function(){
		$(this).css({
			paddingLeft: 5,
			paddingRight: 5
		});
	});
}

/**
 * 聚合图片效果
 */
function polymerEffect(){
	var lis = $('#PolymerBar li:not(.nom)'), mks = lis.find('.mk'), mts = lis.find('.mt');
	lis.hover(function(){
		mts.hide();
		mks.css('opacity', 0);
		var t = $(this), mk = t.find('.mk'), mt = t.find('.mt');
		mk.animate({
			opacity: 0.6
		}, 'fast', function(){
			mt.show();
		});
	}, function(){
		var t = $(this);
		t.find('.mt').hide();
		t.find('.mk').css('opacity', 0);
	}).find('.mk').css('opacity', 0).show();
}

/**
 * 鼠标移到图片上时的放大效果
 */
function imgHoverAmp(){
	var amp = 10, m = amp / 2;
	$('img[hoverAmp]').hover(function(){
		$(this).animate({
			width: '+=' + amp,
			height: '+=' + amp,
			marginLeft: '-=' + m,
			marginTop: '-=' + m
		}, 'fast');
	}, function(){
		$(this).animate({
			width: '-=' + amp,
			height: '-=' + amp,
			marginLeft: '+=' + m,
			marginTop: '+=' + m
		}, 'fast');
	});
}

/**
 * 鼠标移到图片上时的透明度变化
 */
function imgHoverOpacity(){
	$('img[hoverOpacity]').hover(function(){
		$(this).animate({
			opacity: ($(this).attr('hoverOpacity') == 1 ? 0.6 : 1)
		}, 'fast');
	}, function(){
		$(this).animate({
			opacity: ($(this).attr('hoverOpacity') == 1 ? 1 : 0.6)
		}, 'fast');
	}).css('opacity', 0.6).filter('[hoverOpacity="1"]').css('opacity', 1);
}
